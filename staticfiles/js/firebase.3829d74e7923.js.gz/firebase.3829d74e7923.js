
  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  var firebaseConfig = {
    apiKey: "AIzaSyC0xnr3u6UdBSr8B92RrmuhSHHWOxoyEWU",
    authDomain: "drivingliscence-72223.firebaseapp.com",
    databaseURL: "https://drivingliscence-72223-default-rtdb.firebaseio.com",
    projectId: "drivingliscence-72223",
    storageBucket: "drivingliscence-72223.appspot.com",
    messagingSenderId: "590919060724",
    appId: "1:590919060724:web:f467b1e6f946d44a15a2a1",
    measurementId: "G-TZWEBNE6SN"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();

